<br>
<div class="row" style=" margin-left: -98px;">
        <div class="col-md-11 col-md-offset-1">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="row">
                  <div class="col col-xs-6">
                    <h3 class="panel-title" style="color:red"><i class="fa fa-list" aria-hidden="true"></i>&nbsp;Booked Pooja Details</h3>
                  </div>
                  <div class="col col-xs-6 text-right">
                    <a  class="btn btn-sm btn-primary btn-create" href="index.php?page=bookpooja.php"><i class="fa fa-plus-circle" aria-hidden="true"></i>&nbsp;Book Pooja</a>
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th style="width: 10px;">Date</th>
                        <th style="width: 130px;">Client</th>
                        <th style="width: 10px;">Pooja</th>
                        <th style="width: 10px;">Status</th>
                        <th style="width: 90px;">Booking By</th>
                        <th style="width: 80px;">Action</th>
                    </tr> 
                  </thead>
                    <tbody>
                        <tr>
                            <td>01-12-2016</td>
                            <td>Hitarth Patel</td>
                            <td>Poojan 5</td>
                            <td>Completed</td>
                            <td>Vandit Shukla</td>
                            <td align="center">
                              <a class="btn btn-primary"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
                              
                            </td>
                            
                        </tr>

                        
                        
                    </tbody>
                </table>
            
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col col-xs-4">Page 1 of 5
                  </div>
                  <div class="col col-xs-8">
                    <ul class="pagination hidden-xs pull-right">
                      <li><a href="#">1</a></li>
                      <li><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                      <li><a href="#">4</a></li>
                      <li><a href="#">5</a></li>
                    </ul>
                    <ul class="pagination visible-xs pull-right">
                        <li><a href="#">«</a></li>
                        <li><a href="#">»</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
