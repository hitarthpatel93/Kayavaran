<div class="row">
            <div class="col-md-8 col-md-offset-4" style="margin-top: -116px;margin-left: 199px;">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Change Password</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="index.php">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter the old password" name="oldpassword" type="text" >
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter the NewPassword" name="password " type="text" value="">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter the Re-Password" name="password" type="text" value="">
                                </div>
                                
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="commit" value="Submit" class="btn btn-lg btn-success btn-block">
                               
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>