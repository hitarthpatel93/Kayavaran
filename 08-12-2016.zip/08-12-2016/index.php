<?php
session_start();

?>


<?php include("header.php") ?>
<?php include("menu.php") ?>
           
        <div id="page-wrapper">
            <?php if(isset($_REQUEST['page']) && $_REQUEST['page']!=""){
                    include($_REQUEST['page']);

            }else{ ?>
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Welcome To Admin area</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            
            
          

               <?php } ?>
        </div>
        <!-- /#page-wrapper -->
<?php include("footer.php") ?>