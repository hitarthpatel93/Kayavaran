<br>
<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('input[type="radio"]').click(function(){
        if($(this).attr("value")=="red"){
            $(".box").not(".red").hide();
            $(".red").show();
        }
        if($(this).attr("value")=="green"){
            $(".box").not(".green").hide();
            $(".green").show();
        }
        if($(this).attr("value")=="blue"){
            $(".box").not(".blue").hide();
            $(".blue").show();
        }
    });
});
</script>
<style type="text/css">
    .box{
        padding: -1000px;
        display: none;
        margin-top: 20px;
        
    }


    
</style>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
           <div class="panel-body">
                <div class="row">
                  <div class="col col-xs-6">
                    <h3 class="panel-title" style="color:red"><i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Book Poojan</h3>
                  </div>
                  <div class="col col-xs-6 text-right">
                    <a  class="btn btn-sm btn-primary btn-create" href="index.php?page=bookpoojan_list.php"><i class="fa fa-plus-circle" aria-hidden="true"></i>&nbsp;Book Poojan List</a>
                  </div>
                </div><hr>
                <div class="col-md-12">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="radios">Status</label>
                                <div class="col-md-4" style="margin-left: -138px;"> 
                                    <label class="radio-inline" for="radios-0">
                                        <input name="colorRadio" id="radios-0" value="red" type="radio">New
                                    </label> 
                                    <label class="radio-inline" for="radios-1">
                                        <input name="colorRadio" id="radios-1" value="green" type="radio">Exist
                                    </label>
                                </div>
                        </div>
                    </div>
                    
                </div>
                
                <div class="col-md-12 red box">
                   <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Name&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter the name" type="text" maxlength="10">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Email&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter the valid email" type="text" maxlength="10">
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="col-md-12 red box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Mobile&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter The MobileNumber" type="text" maxlength="10">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Pooja&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <select id="selectbasic" name="selectbasic" class="form-control">
                                      <option value="1">Pooja1</option>
                                      <option value="2">Pooja2</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <div class="col-md-12 red box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">DOB&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter the date of birth" type="text" maxlength="10">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Price&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter the price" type="text" maxlength="10">
                            </div>
                        </div>
                    </div>

                    
                     
                </div>

                <div class="col-md-12 red box">
                    

                    <div class="col-md-6">
                      
                        <div class="form-group">
                            <label class="control-label col-md-3">Material &nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="textarea" name="textarea" placeholder="Enter the material of poojan"></textarea>
                            </div>
                        </div>
                   
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Address&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="textarea" name="textarea" placeholder="Enter the residency address"></textarea>
                            </div>
                        </div>
                    </div> 
                     
                </div>


                <div class="col-md-12 red box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="radios">Status</label>
                                <div class="col-md-4" style="margin-left: -38px;"> 
                                    <label class="radio-inline" for="radios-03">
                                      <input name="radios" id="radios-03" value="Pending" checked="checked" type="radio">
                                      Pending
                                    </label> 
                                    <label class="radio-inline" for="radios-04" style="margin-top: -43px;margin-left: 79px;">
                                      <input name="radios" id="radios-04" value="Completed" type="radio">
                                      Completed
                                    </label> 
                                    <label class="radio-inline" for="radios-05" style="margin-top: -83px;margin-left: 175px;">
                                        <input name="radios" id="radios-05" value="Cancelled" type="radio">
                                      Cancelled
                                    </label>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 green box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Client&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <select id="selectbasic" name="selectbasic" class="form-control">
                                      <option value="1">Client one</option>
                                      <option value="2">Client two</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Pooja&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <select id="selectbasic" name="selectbasic" class="form-control">
                                      <option value="1">Pooja1</option>
                                      <option value="2">Pooja2</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                </div>

                <div class="col-md-12 green box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Price&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter the price" type="text" maxlength="10">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                      
                        <div class="form-group">
                            <label class="control-label col-md-3">Material &nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="textarea" name="textarea" placeholder="Enter the material of poojan"></textarea>
                            </div>
                        </div>
                   
                    </div>


                </div>

                <div class="col-md-12 green box">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="radios">Status</label>
                                <div class="col-md-4" style="margin-left: -38px;"> 
                                    <label class="radio-inline" for="radios-06">
                                      <input name="radios" id="radios-06" value="Pending" checked="checked" type="radio">
                                      Pending
                                    </label> 
                                    <label class="radio-inline" for="radios-07" style="margin-top: -43px;margin-left: 79px;">
                                      <input name="radios" id="radios-07" value="Completed" type="radio">
                                      Completed
                                    </label> 
                                    <label class="radio-inline" for="radios-08" style="margin-top: -83px;margin-left: 175px;">
                                        <input name="radios" id="radios-08" value="Cancelled" type="radio">
                                      Cancelled
                                    </label>
                                </div>
                        </div>
                    </div>
                </div>
                  
                <div class="col-md-12"><hr>
                    <a href="index.php?page=bookpoojan_list.php" type="button" class="btn btn-success" style="margin-left: 364px;margin-top: 16px;"><i class="fa fa-floppy-o" aria-hidden="true"></i>
                    &nbsp;Save</a>
                    <button type="button" class="btn btn-success" style="margin-top: 16px;"><i class="fa fa-print" aria-hidden="true"></i>
                    &nbsp;Print</button>
                    <button type="button" class="btn btn-danger" style="margin-top: 16px;"><i class="fa fa-times-circle-o" aria-hidden="true"></i>
                    &nbsp;Cancle</button>
                </div>

            </div>
        </div>
        
        
    </div>
</div>



