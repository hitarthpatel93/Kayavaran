
<br>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
           <div class="panel-body">
                <div class="row">
                  <div class="col col-xs-6">
                    <h3 class="panel-title" style="color:red"><i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;Add New Client</h3>
                  </div>
                  <div class="col col-xs-6 text-right">
                    <a  class="btn btn-sm btn-primary btn-create" href="index.php?page=clientlist.php"><i class="fa fa-plus-square" aria-hidden="true"></i>&nbsp;List Clients</a><hr>
                  </div>
                </div>
                <div class="col-md-12">
                   <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Name&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter The Name" type="text">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Email&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="Enter The Email" type="text" maxlength="10">
                            </div>
                        </div>
                    </div> 
                </div>
                
                <div class="col-md-12">
                   <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Mobile&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9" style="margin-top: 10px;">
                                <input class="form-control" placeholder="Enter The Phone Number" type="text">
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Date&nbsp;<span style="color:red">*</span></label>
                            <div class="col-md-9" style="margin-top: 10px;">
                                <input class="form-control" placeholder="Enter The Phone Number" type="text">
                            </div>
                        </div>
                    </div>
                </div><br><br>
                <div class="col-md-12">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label col-md-3">Address&nbsp;<span style="color:red;">*</span></label>
                            <div class="col-md-9">
                                <textarea class="form-control" id="textarea" name="textarea" placeholder="Enter Address" style="margin-top: 10px;"></textarea>
                            </div>
                        </div>
                    </div> 
                </div>

                
                
                <div class="col-md-12"><hr>
                        <a href="index.php?page=poojan_list.php" type="button" class="btn btn-success" style="margin-left: 364px;"><i class="fa fa-floppy-o" aria-hidden="true"></i>
                        &nbsp;Save</a>
                        <button type="button" class="btn btn-success"><i class="fa fa-print" aria-hidden="true"></i>
                        &nbsp;Print</button>
                        <button type="button" class="btn btn-danger"><i class="fa fa-times-circle-o" aria-hidden="true"></i>
                        &nbsp;Cancle</button>
                </div>
                

            </div>
        </div>
        
        
    </div>
</div>