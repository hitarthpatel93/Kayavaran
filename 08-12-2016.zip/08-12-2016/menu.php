          <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                            <a href="index.php?page=dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            
                        </li>
                        
                        <li>
                            <a href="index.php?page=danationlist.php"><i class="fa fa-file-text fa-fw"></i>Donation</a>
                        </li>
                        <li>
                            <a href="index.php?page=bookpoojan_list.php"><i class="fa fa-book fa-fw"></i>Book Pooja</a>
                        </li>
                        <li>
                            <a href="index.php?page=calander.php"><i class="fa fa-calendar fa-fw"></i>Calander</a>  
                        </li>
                        <li>
                            <a href="index.php?page=clientlist.php">&nbsp;<i class="fa fa-user" aria-hidden="true"></i>&nbsp;Clients</a>
                        </li>
                        <li>
                            <a href="index.php?page=poojan_master_list.php"><i class="fa fa-list-ul fa-fw"></i>Poojan</a>
                        </li>
                        <li>
                            <a href="index.php?page=userlist.php">&nbsp;<i class="fa fa-user" aria-hidden="true"></i>&nbsp;User</a>
                        </li>
                        <li>
                            <a href="login.php"><i class="fa fa-sign-out fa-fw"></i>Logout</a>
                        </li>
                        
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>