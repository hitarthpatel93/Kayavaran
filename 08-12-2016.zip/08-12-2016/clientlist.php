<br>
<div class="row" style=" margin-left: -98px;">
        <div class="col-md-11 col-md-offset-1">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="row">
                  <div class="col col-xs-6">
                    <h3 class="panel-title" style="color:red"><i class="fa fa-list" aria-hidden="true"></i>&nbsp;Client Details</h3>
                  </div>
                  <div class="col col-xs-6 text-right">
                    <a  class="btn btn-sm btn-primary btn-create" href="index.php?page=client.php"><i class="fa fa-plus-circle" aria-hidden="true"></i>&nbsp;Add Clients</a>
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                        <th style="width: 180px;">Name</th>
                        <th style="width: 30px;">Mobile</th>
                        <th style="width: 10px;">Total Pooja</th>
                        <th style="width: 10px;">Total Money</th>
                        <th style="width: 80px;">Actions</th>
                    </tr> 
                  </thead>
                    <tbody>
                        <tr>
                            <td>Patel Hitarth</td>
                            <td>+91 9978454541</td>
                            <td>5</td>
                            <td>5000</td>
                            <td align="center">
                              <a class="btn btn-primary"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
                              <a class="btn btn-success"><em class="fa fa-eye"></em></a>
                              <a class="btn btn-info"><em class="fa fa-envelope"></em></a>
                            </td>
                            
                        </tr>

                        <tr>
                            <td>Soyab Rana</td>
                            <td>+91 9978454541</td>
                            <td>8</td>
                            <td>150000</td>
                            <td align="center">
                              <a class="btn btn-primary"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
                              <a class="btn btn-success"><em class="fa fa-eye"></em></a>
                              <a class="btn btn-info"><em class="fa fa-envelope"></em></a>
                            </td>
                            
                        </tr>

                        <tr>
                            <td>Vandit Shukla</td>
                            <td>+91 9978454541</td>
                            <td>25</td>
                            <td>25000</td>
                            <td align="center">
                              <a class="btn btn-primary"><em class="fa fa-pencil"></em></a>
                              <a class="btn btn-danger"><em class="fa fa-trash"></em></a>
                              <a class="btn btn-success"><em class="fa fa-eye"></em></a>
                              <a class="btn btn-info"><em class="fa fa-envelope"></em></a>
                            </td>
                            
                        </tr>
                        
                    </tbody>
                </table>
            
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col col-xs-4">Page 1 of 5
                  </div>
                  <div class="col col-xs-8">
                    <ul class="pagination hidden-xs pull-right">
                      <li><a href="#">1</a></li>
                      <li><a href="#">2</a></li>
                      <li><a href="#">3</a></li>
                      <li><a href="#">4</a></li>
                      <li><a href="#">5</a></li>
                    </ul>
                    <ul class="pagination visible-xs pull-right">
                        <li><a href="#">«</a></li>
                        <li><a href="#">»</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
