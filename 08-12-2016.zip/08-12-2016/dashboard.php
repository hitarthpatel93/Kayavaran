     <br>       
    <div class="row">
        <div class="col-lg-4 col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-users fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge">26</div>
                                    <div>Total Clients</div>
                            </div>
                        </div>
                    </div>
                       
                </div>
            </div>
        <div class="col-lg-4 col-md-6">
            <div class="panel panel-green">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-tasks fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge">12</div>
                            <div>Total Pooja</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="panel panel-yellow">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-inr fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <div class="huge">50,000</div>
                            <div>Total Payments</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
    </div>

  
    <div class="row">
        <div class="col-md-11 col-md-offset-1" style="margin-left: 53px;">

            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="row">
                  <div class="col col-xs-6">
                    
                    <h3 class="panel-title" style="color:red"><i class="fa fa-list" aria-hidden="true"></i>&nbsp; Upcoming Poojan Details</h3>
                  </div>
                  
                </div>
              </div>
              <div class="panel-body">
                <table class="table table-striped table-bordered table-list">
                  <thead>
                    <tr>
                       
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Date</th>
                        <th>Poojan</th>
                    </tr> 
                  </thead>
                  <tbody>
                        <tr>
                            <td>John Doe</td>
                            <td>+91 9978493971</td>
                            <td>08-12-2016</td>
                            <td>Poojan1</td>
                        </tr>
                        <tr>
                            <td>John Doe</td>
                            <td>+91 9978493971</td>
                            <td>04-01-2017</td>
                            <td>Poojan5</td>
                        </tr>
                        <tr>
                            <td>Hillery Bomb</td>
                            <td>+91 9978493971</td>
                            <td>31-12-2016</td>
                            <td>Poojan9</td>
                        </tr>
                        <tr>
                            <td>Hillery Bomb</td>
                            <td>+91 9978493971</td>
                            <td>31-12-2016</td>
                            <td>Poojan5</td>
                        </tr>
                        <tr>
                            <td>Hillery Bomb</td>
                            <td>+91 9978493971</td>
                            <td>31-12-2016</td>
                            <td>Poojan6</td>
                        </tr>
                    </tbody>
                </table>
            
              </div>
              
            </div>

        </div>
    </div>